let dragged = null;

function openKit(id){
  document.querySelectorAll(".kitPage").forEach(p=>{
    p.classList.remove("active");
  });
  document.getElementById(id).classList.add("active");
}

function createKit(id){
  const el = document.getElementById(id);

  const tiers=[
    "LT5","HT5",
    "LT4","HT4",
    "LT3","HT3",
    "LT2","HT2",
    "LT1","HT1"
  ];

  tiers.forEach(t=>{
    const row=document.createElement("div");
    row.className="tier";

    row.innerHTML=`
      <div class="label">${t}</div>
      <div class="zone" ondrop="drop(event)" ondragover="allow(event)"></div>
    `;

    el.appendChild(row);
  });
}

["speed","diamond","sumo","manhunt","vanilla"].forEach(createKit);

function addPlayer(){
  const name=document.getElementById("playerName").value;
  if(!name) return;

  const div=document.createElement("div");
  div.className="player";
  div.draggable=true;
  div.textContent=name;

  document.querySelector(".kitPage.active .zone").appendChild(div);
  document.getElementById("playerName").value="";
}

document.addEventListener("dragstart",e=>{
  if(e.target.classList.contains("player")){
    dragged=e.target;
  }
});

function allow(e){e.preventDefault();}

function drop(e){
  e.preventDefault();
  if(dragged){
    e.currentTarget.appendChild(dragged);
  }
}
